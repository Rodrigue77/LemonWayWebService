﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsConsumer.localhost;

namespace WindowsFormsConsumer
{
    public partial class Form1 : Form
    {

        private BusyForm busyForm = new BusyForm();
        public Form1()
        {
            InitializeComponent();
        }

        /// <summary>
        /// get Fibonacii value from webservice
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnShowFibonacci_Click(object sender, EventArgs e)
        {
            try
            {
                Fibonacci fibonacci = new Fibonacci();
                int result = 0;

                if (backgroundWorker1.IsBusy != true)
                {

                    busyForm.Show();
                    Thread.Sleep(2000);
                    Thread thread = new Thread(() =>
                    {
                        result = fibonacci.GetFibonacci(10); 
                    });
                    thread.Start();

                    busyForm.Close();
                    MessageBox.Show(result.ToString());
                    backgroundWorker1.RunWorkerAsync();
                }
                
            }
            catch
            {
                throw  new NotImplementedException();
            }
        }


    }
}
